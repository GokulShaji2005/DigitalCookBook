/**
 * 
 */
/**
 * 
 */
module digitalCookBook {
	requires java.desktop;
	requires java.sql;
	

	
}